console.log("file: /var/www/html/javaScript/myscript.js");
